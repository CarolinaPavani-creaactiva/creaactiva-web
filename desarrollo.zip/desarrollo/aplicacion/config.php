<?php
// NO SE SUBE AL SERVIDOR
return [
    'env' => 'development',
    'base_url' => '/creaactiva-web/desarrollo/',
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'user' => 'root',
        'pass' => '0772',
        'name' => 'qzv741'
    ]
];
